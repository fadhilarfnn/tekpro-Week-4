public class Commission extends Hourly{
    private double totalSales;
    private double commissionRate;

    public Commission(String eName, String eAddress, String ePhone, String socSecNumber, double rate, double commissionRate){
        super(eName, eAddress, ePhone, socSecNumber, rate);
        this.commissionRate = commissionRate;
    }

    public void addSales (double totalSales){
        this. totalSales += totalSales;
    }

    public double pay(){
        double totalpay = (commissionRate * totalSales) + super.pay();
        totalSales = 0.0;
        return totalpay;
    }

    public String toString(){
        String result = super.toString();
        result += "\nTotal sales:" + totalSales;
        return result;
    }
}